const { RichEmbed } = require('discord.js');

module.exports = {
    name: "ping",
    category: "info",
    description: "Returns latency and API ping",
    run: async (client, message, args) => {
       const msg = await message.channel.send(`🏓 Pinging....`).then(m => m.delete(100));

       const useruser = "Request from: " + message.author.username;
   const userurl = message.author.avatarURL;
   let botembed = new RichEmbed()
       botembed.setColor("#576bff")
       botembed.setDescription(`:ping_pong: Pong! **\`${client.pings[0]}ms\`**`)
       botembed.setFooter(useruser, userurl)
       botembed.setTimestamp()

       message.channel.send(botembed)


}
    }
