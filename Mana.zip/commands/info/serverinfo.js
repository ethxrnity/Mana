const { RichEmbed } = require('discord.js');
const { stripIndents } = require("common-tags");
const { getMember, formatDate } = require("../../functions.js");

module.exports = {
  name: "serverinfo",
  aliases: ["server"],
  category: "info",
  description: "Returns information about server",

  run: async (client, message, args) => {
    const msg = await message.channel.send(`:gear: Working on your request...`).then(m => m.delete(100));
let online = message.guild.members.filter(member => member.user.presence.status !== 'offline');
    let day = message.guild.createdAt.getDate()
    let month = 1 + message.guild.createdAt.getMonth()
    let year = message.guild.createdAt.getFullYear()
    let sicon = message.guild.iconURL;
    const useruser = "Request from: " + message.author.username;
    const userurl = message.author.avatarURL;
    let botembed = new RichEmbed()
    botembed.setAuthor(message.guild.name, sicon)
    botembed.setColor("#576bff")
    botembed.setThumbnail(sicon)
    botembed.addField(`Server information`, stripIndents`**Server name**: ${message.guild.name}
    **Owner**: ${message.guild.owner.user.tag}
    **Roles**: ${message.guild.roles.size}
    **Channels**: ${message.guild.channels.size}`, true)
    botembed.addField(`User information`, stripIndents`**Users**: ${message.guild.memberCount}
    **Bots**: ${message.guild.members.filter(m => m.user.bot).size}
    **Online**: ${online.size}`, true)

    botembed.setFooter(useruser, userurl)
    botembed.setTimestamp()

    message.channel.send(botembed)


    }
    }
