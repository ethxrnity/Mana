const { RichEmbed } = require('discord.js');
const { stripIndents } = require("common-tags");
const { getMember, formatDate } = require("../../functions.js");

module.exports = {
  name: "gay",
  category: "info",
  description: "Returns how much gay you are",
  run: async (client, message, args) => {
           const member = getMember(message, args.join(" "));
           const msg = await message.channel.send(`:gear: Working on your request...`).then(m => m.delete(100));

let gay = Math.round(Math.random() * 100);

let gayembed = new RichEmbed()
    .setColor("#576bff")
    .setDescription(`I think that ${member.user.username} is ${gay}% gay!`)
    .setFooter("Request from: " + message.author.username, message.author.avatarURL);
message.delete(10);
return message.channel.send(gayembed);
}

}
