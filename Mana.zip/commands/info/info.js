const { RichEmbed } = require('discord.js');
const { stripIndents } = require("common-tags");

module.exports = {
  name: "info",
  aliases: ["about", "bot", "botinfo"],
  category: "info",
  description: "Returns bot informations",
  run: async (client, message, args) => {
           const msg = await message.channel.send(`:gear: Working on your request...`).then(m => m.delete(100));

    const useruser = "Request from: " + message.author.username;
const userurl = message.author.avatarURL;
let botembed = new RichEmbed()
    botembed.setColor("#576bff")
    botembed.setThumbnail("https://upload.hicoria.com/files/p13HTkGZ.png")
    botembed.addField(`Bot information`, stripIndents`Developer: <@574849327650963469>
    Support server: [LINK](https://discord.gg/K83U2aC)
    Invite link: [LINK](https://discord.com/oauth2/authorize?client_id=588450296955535389&scope=bot&permissions=1345715264)`)
    botembed.setFooter(useruser, userurl)
    botembed.setTimestamp()

    message.channel.send(botembed)


}
 }
