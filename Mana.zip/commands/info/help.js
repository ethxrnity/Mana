const { RichEmbed } = require('discord.js');
const { stripIndents } = require("common-tags");

module.exports = {
  name: "help",
  aliases: ["?", "commands"],
  category: "info",
  description: "Returns bot help",
  run: async (client, message, args) => {
           const msg = await message.channel.send(`:gear: Working on your request...`).then(m => m.delete(100));

let helpDM = new RichEmbed()
    .setColor("#576bff")
    .setAuthor("List of commands for Ellen", client.user.avatarURL)
    .setDescription("Ellen has prefix set on ``e!`` \n Support server: **[LINK](https://discord.gg/K83U2aC)**")
    .addBlankField()
    .addField(":trophy: | **Info**", "``user`` ``server`` ``info`` ``help`` ``say`` ``mute`` ``purge`` ``ping`` ``serverlist`` ``ban`` ``kick`` \n\n")
    .addField(":8ball: | **Fun**", "``avatar`` ``8ball`` ``meme`` ``cat`` ``dog`` ``gay`` \n\n")
    .addBlankField()
    .addField(":globe_with_meridians: | **Web**", "**[LINK](https://ellen.ethxrnity.eu)**", true)
    .addField(":incoming_envelope: | **Developer**", "<@574849327650963469>", true)

let help = new RichEmbed()
    .setTitle("Check your PM")
    .setColor("#576bff")
    .setDescription(":mailbox:  | I have sent you something to your PM!")

message.channel.send(help);
message.author.send(helpDM);

}
}
