module.exports = {
  name: "status",
  category: "info",
  description: "Set a new status for bot",
  usage: "[status]",
  run: async (client, message, args) => {

    if(message.author.id !== "574849327650963469") return message.channel.send("⛔ **Tento příkaz platí pouze pro Developery**");

    if(args[0] == "online") return client.user.setStatus("online");

    if(args[0] == "invisible") return client.user.setStatus("invisible");

    if(args[0] == "dnd") return client.user.setStatus("dnd")

    if(args[0] == "idle") return client.user.setStatus("idle");

  }
}
