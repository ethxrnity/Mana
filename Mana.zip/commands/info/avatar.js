const { RichEmbed } = require('discord.js');

module.exports = {
  name: "avatar",
  category: "info",
  description: "Return users avatar",
  run: async (client, message, args) => {
           const msg = await message.channel.send(`:gear: Working on your request...`).then(m => m.delete(100));

let user = message.mentions.users.first() || message.author;

            let embed = new RichEmbed()
            .setImage(user.displayAvatarURL)
            .setColor("#576bff")
            .setTimestamp()
            .setFooter("Request from: " + message.author.username, message.author.avatarURL);


            message.channel.send(embed)
  }
}
