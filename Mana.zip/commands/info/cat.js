const { RichEmbed } = require('discord.js');
const { stripIndents } = require("common-tags");
const superagent = require('superagent');

module.exports = {
  name: "cat",
  category: "info",
  description: "Returns a cute kitty",
  run: async (client, message, args) => {
           const msg = await message.channel.send(`:gear: Working on your request...`).then(m => m.delete(100));

let{body} = await superagent
.get(`http://aws.random.cat/meow`);

let embed = new RichEmbed()
.setColor("#576bff")
.setFooter("Request from: " + message.author.username, message.author.avatarURL)
.setImage(body.file);

message.channel.send(embed);
  }


}
