const { RichEmbed } = require('discord.js');
const { getMember, formatDate } = require("../../functions.js");

const VERIFIED = "721123061679521802";

module.exports = {
  name: "verify",
  category: "moderation",
  description: "You will be verified on Ethx's Lab. server!",
  run: async (client, message, args) => {
    const member = getMember(message, args.join(" "));


message.member.addRole(VERIFIED);

const embed = new RichEmbed()
    .setColor("#576bff")
    .setDescription ("<a:Verify:708749864191655937> User was successfully verified")
    .setFooter("Request from: " + message.author.username, message.author.avatarURL)

    .setTimestamp()
    .then(m => m.delete(5000));

let msg = await message.channel.send(embed)
    .then(function (msg) {
        message.delete({timeout: 1000});
        }).catch(function(error) {
        console.log(error);
    });
}
}
