const { RichEmbed } = require('discord.js');
const { stripIndents } = require("common-tags");

module.exports = {
  name: "say",
  category: "moderation",
  description: "Your message will be send by Ellen",
  run: async (client, message, args) => {
           const msg = await message.channel.send(`:gear: Working on your request...`).then(m => m.delete(100));

           if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.sendMessage(":no_entry_sign: You dont have enough permissions to do this!")

             const sayMessage = args.join(" ");

             let esayEmbed = new RichEmbed()
             .setColor("#576bff")
             .setDescription (`${sayMessage}`)
             .setFooter("Written by: " + message.author.username, message.author.avatarURL);

             const esayMessage = args.join(" ");
             message.delete().catch(O_o=>{});

             message.channel.send(esayEmbed)
    .then(m => m.delete(3000));
}
}
