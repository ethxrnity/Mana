const { RichEmbed } = require('discord.js');
const { stripIndents } = require("common-tags");
const { getMember, formatDate } = require("../../functions.js");

module.exports = {
  name: "purge",
  category: "moderation",
  aliases: ["clear"],
  description: "Command that will clear unnecessary messages",
  run: async (client, message, args) => {
           const msg = await message.channel.send(`:gear: Working on your request...`).then(m => m.delete(100));


  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.sendMessage(":no_entry_sign: You dont have enough permissions to do this!")

  if (isNaN(args[0]) || parseInt(args[0]) <= 0) return message.reply("Thats not a valid number.")

  if (!message.guild.me.hasPermission("MANAGE_MESSAGES")) return message.reply("Sorry i cant delete message. Give me permissions to do it please!")

  let deleteAmount;

  if (parseInt(args[0]) > 100) {
      deleteAmount = 100;
  } else {
      deleteAmount = parseInt(args[0]);
  }

  message.channel.bulkDelete(args[0])
           var cleanEmbed = new RichEmbed()

           .setDescription(`Successfully deleted **${args[0]}** unnecessary messages!`)
           .setFooter('Request from: ' + message.author.username, message.author.avatarURL)
           .setColor('#576bff')

           .setTimestamp();
           message.channel.send(cleanEmbed);

}
}
